
#ifndef RFAST_H
#define RFAST_H

#include "Rfast/matrix.hpp"
#include "Rfast/vector.hpp"

#endif
