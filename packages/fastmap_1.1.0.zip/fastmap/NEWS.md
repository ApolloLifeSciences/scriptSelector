fastmap 1.1.0
=============

* Added `faststack()` and `fastqueue()`. (#15)

fastmap 1.0.1
=============

* Fixed #13: fastmap.cpp now explicitly includes the algorithm header, which is needed on some platforms to successfully compile.
