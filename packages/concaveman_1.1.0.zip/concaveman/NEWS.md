# concaveman 1.1.0

- Support for the `SpatialPoint` classes has been removed. It is now advised to transform data to and from `sf` format outside of the `concaveman` function.
- fixes to comply with `dplyr` 1.0 and `sf` 0.9

# concaveman 1.0.0

- initial release
- supports different input and output formats (matrix of coordinates, `SpatialPoints*`, `sf`)
